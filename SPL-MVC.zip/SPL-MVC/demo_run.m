% 
%solve the following problem��
% SPL for auto-weighted multi-view clustering
% min\sum_m\eta^{(m)}||diag(v^{(m)})(X^{(m)}-GF^{(m)}^{T})||_{2,1}+f(\lambda,V)
% s.t. g \in {0,1}, v^{(m)} \in [0.1]
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% written by Shudong Huang on 15/7/2018
% Reference: Yazhou Ren, Shudong Huang, Peng Zhao, Minghao Han, Zenglin Xu. 
% Self-paced and auto-weighted multi-view clustering. 
% In: Neurocomputing.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ATTN1: This package is free for academic usage. The code was developed by Mr. SD. Huang (huangsd@std.uestc.edu.cn). You can run
% it at your own risk. For other purposes, please contact Prof. Yazhou Ren (yazhou.ren@uestc.edu.cn)
%
% ATTN2: This package was developed by Mr. SD. Huang (huangsd@std.uestc.edu.cn). For any problem concerning the code, please feel
% free to contact Mr. Huang.
%
% Input:
% inXcell: v by 1 cell, and the size of each cell is n*d_v
% labels: groundtruth, n*1 
%
% Output:
% outG0: the output cluster indicator (n by c)
% 
% Example:
%
% begin ... 
disp('SPL Multi-view Clustering ...');

% data: Handwritten numerals
load('Handwritten_numerals.mat') 

% run ...
[outG0, alpha] = nonlinear_self_paced_mvkc(data, labels);

% cluster results
res = ClusteringMeasure(labels,outG0)