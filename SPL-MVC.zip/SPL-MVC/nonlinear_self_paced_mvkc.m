function [outG0, alpha] = nonlinear_self_paced_mvkc(inXCell, labels)
% solve the following problem��
% SPL for auto-weighted multi-view clustering
% min\sum_m\eta^{(m)}||diag(v^{(m)})(X^{(m)}-GF^{(m)}^{T})||_{2,1}+f(\lambda,V)
% s.t. g \in {0,1}, v^{(m)} \in [0.1]
%
% input: 
%       inXcell: v by 1 cell, and the size of each cell is n*d_v
%       inPara: parameter cell
%               inPara.maxIter: max number of iterator
%               inPara.thresh:  the convergence threshold
%               inPara.numCluster: the number cluster
%               inPara.r: the parameter to control the distribution of the
%                         weights for each view
%       inG0: init common cluster indicator
% output:
%       outG0: the output cluster indicator (n by c)
%       outFcell: the cluster centroid for each view (d by c by v)
%       obj: obj value
%       outNumIter: number of iterator

% parameter settings
maxIter = 50;
thresh = 1e-6;

% number of view
numView = length(inXCell); 

% satisfy d_v*n and normalization
for i = 1:numView
    inXCell{i} = mapminmax(inXCell{i}',0,1);  
end

% number of samples 
nSmp = size(inXCell{1}, 2); 

% number of clusters
C_num = length(unique(labels));

% initialize G0
% Cidx = kmeans(inXCell{1}', C_num, 'emptyaction', 'singleton', 'replicates', 100, 'display', 'off');
Cidx = kmeans(inXCell{1}', C_num, 'emptyaction', 'singleton');
inG0 = zeros(nSmp,C_num);
for i=1:nSmp
   inG0(i,Cidx(i))=1;
end
G0 = inG0;

% initialize alpha
alpha = ones(numView, 1)/numView; 

% initialize common indicator D3
for v = 1: numView    
    D4{v} = sparse(diag(ones(nSmp, 1))* alpha(v));
end
% % Fix D3{v}, G0, alpha, update F{v}
% for v = 1: numView
%     M = G0'*D4{v}*G0;
%     N = inXCell{v}*D4{v}*G0;
%     F{v} = N/M;
% end
% clear M N;
% tmp = 1/(1-r);
obj = zeros(maxIter, 1);
update=1.15;   % [1.10, 1.15, 1.25, 1.40]
% loop
for iter = 1: maxIter
    fprintf('processing iteration %d...\n', iter);
    
    % Fix D3{v}, G0, alpha, update F{v}
    for v = 1: numView
        M = (G0'*D4{v}*G0);
        N = inXCell{v}*D4{v}*G0;
        F{v} = N/M;       
    end      
    
    
    % Fix D3{v}, F{v}, update G0    
    for i = 1:nSmp
        dVec = zeros(numView, 1);
        for v = 1: numView
            xVec{v} = inXCell{v}(:,i);
            tt = diag(D4{v});
            dVec(v, 1) = tt(i);
        end
        G0(i,:) = searchBestIndicator(dVec, xVec, F);
    end
    
    % Fix F{v}, G0, D4{v}, update alpha
    h = zeros(numView, 1);
    for v = 1: numView
        E{v} = (inXCell{v} - F{v}*G0')';
        Ei2{v} = sqrt(sum(E{v}.*E{v},2)+eps);
    end
    
    %initalize lamida
    if iter == 1
        for j = 1: numView
            [m(j,:),n1]= sort(Ei2{j});
            lamida(j,:)=m(j,round(median(n1)))*1.05; % more than half 
        end
    end
    
    % set zeta 
   zeta = lamida/2;
   
  for i = 1:numView
    for j = 1:nSmp
        % Ei2{i}(j) = Ei2{i}(j)*sqrt((1+exp(-lamida(i,1))/1+exp(Ei2{i}(j)-lamida(i,1))));
         if Ei2{i}(j) <= (zeta(i,1)*lamida(i,1))/(zeta(i,1)+lamida(i,1))
             Ei2{i}(j) = Ei2{i}(j);    % v = 1;
         elseif Ei2{i}(j) >= lamida(i,1)
             Ei2{i}(j) = 0.000000001;  % v = 0;
         else
             Ei2{i}(j) = Ei2{i}(j)*zeta(i,1)*(1/(Ei2{i}(j)+eps)-1/(lamida(i,1)+eps)); % v = zeta*(1/Ei2{i}(j)-1/lamida(i,1));
         end
    end
  end 
    % Fix F{v}, G0, update alpha(v) and D4{v}
    for v = 1: numView
        h(v) = sum(Ei2{v});
        alpha(v) = 0.5/sqrt(h(v));
    end
   % alpha = ((r*h).^tmp)/(sum(((r*h).^tmp)));
    for v=1:numView
        D4{v} =sparse(diag(0.5./Ei2{v}*alpha(v)));
    end
    
    % calculate the obj
    obj(iter) = 0;
    for v = 1: numView
        obj(iter) = obj(iter) + alpha(v)*sum(Ei2{v});
    end
    if(iter > 1)
        diff = abs(obj(iter-1) - obj(iter))/obj(iter-1);
        if(diff < thresh)
            break;
        end
    end
    % lamida update
    lamida=lamida*update;
end
% debug
% figure, plot(1: length(obj), obj);
% outObj = obj;
% outNumIter = t;
% outFCell = F;
% outAlpha = alpha;
% outAlpha_r = alpha.^r;
for i = 1:C_num
    G0(:,i)=i*G0(:,i);
end
 outG0 = sum(G0,2);
end
%% function searchBestIndicator
function outVec = searchBestIndicator(dVec, xCell, F)
% solve the following problem,
numView = length(F);
c = size(F{1}, 2);
tmp = eye(c);
obj = zeros(c, 1);
for j = 1: c
    for v = 1: numView
        obj(j,1) = obj(j,1) + dVec(v) * (norm(xCell{v} - F{v}(:,j))^2);
    end
end
[min_val, min_idx] = min(obj);
outVec = tmp(:, min_idx);
end
